package com.thedotcoffee.pos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
