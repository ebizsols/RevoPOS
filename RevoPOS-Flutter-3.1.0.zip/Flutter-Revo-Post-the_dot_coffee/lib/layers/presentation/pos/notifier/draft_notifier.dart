import 'package:flutter/cupertino.dart';

class DraftNotifier with ChangeNotifier {

}